$ErrorActionPreference = "Stop"
$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$VenvPath = Join-Path $PackageRoot ".venv"
if (-not (Test-Path $VenvPath)) {
    throw "未找到现有 .venv；请先执行 install.ps1。"
}
& (Join-Path $VenvPath "Scripts\python.exe") -m pip install --no-index --find-links (Join-Path $PackageRoot "vendor") -r (Join-Path $PackageRoot "requirements.txt")
Write-Host "M6 依赖已按包内 requirements.txt 完成离线升级；请按 M6_OPERATIONS.md 做 profile/配置兼容性检查。"
