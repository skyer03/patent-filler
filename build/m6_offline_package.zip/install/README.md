# M6 离线安装包

本包用于 M6 阶段的本地队列、断点续填、profile/配置版本和诊断脱敏。安装程序不访问网络，也不会自动点击保存、提交、返回或删除。

## 首次安装

1. 由管理员将审核过的离线 wheel 放入 `vendor/`。
2. 在 Windows 终端执行 `install/install.ps1`。
3. 安装后先用 `python -m unittest discover -s tests -v`（若包内包含测试）或现场预置的验收样本做离线冒烟测试。
4. 首次现场运行先选择只识别；用户确认 profile 和页面锚点后才进行单步操作。

## 升级与回滚

升级前先备份 `.m6` 数据目录。复制新版本文件后执行 `install/upgrade.ps1`；若 profile 或人工配置验收失败，使用 M6 页面 profile/配置仓库的显式 rollback，再恢复队列 checkpoint。
