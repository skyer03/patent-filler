@echo off
setlocal
set "ROOT=%~dp0"
"%ROOT%.venv\Scripts\python.exe" -m app m6 list --queue "%ROOT%.m6\queue.json"
endlocal
