# M5 现场包

这是只依赖本地文件的现场源安装包。它不连接公司内网、不注入网页脚本，也不会自动点击保存、提交、返回或删除。

## 首次安装

1. 在有权限的 Windows 终端执行 `install.ps1`；脚本只使用包内的 `vendor` 目录，不访问网络。
2. 如果现场没有预置依赖 wheel，请由管理员把与 `requirements.txt` 匹配的 wheel 放入 `vendor` 后再安装。
3. 首次进入内网后，先执行只识别：

   `run_recognition.cmd C:\path\field.png`

4. 审核标注截图和 JSON 后，再准备显式的 `actions.json` 做单步运行。没有明确授权时不要使用 `--yes`。

`resources/image_templates/intranet_v1` 当前没有伪造的像素模板；现场审核后的稳定控件小截图应按 manifest 登记后再放入该目录。
