$ErrorActionPreference = "Stop"
$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$VenvPath = Join-Path $PackageRoot ".venv"
if (-not (Test-Path $VenvPath)) {
    python -m venv $VenvPath
}
& (Join-Path $VenvPath "Scripts\python.exe") -m pip install --no-index --find-links (Join-Path $PackageRoot "vendor") -r (Join-Path $PackageRoot "requirements.txt")
Write-Host "M5 现场包已安装到 $VenvPath"
