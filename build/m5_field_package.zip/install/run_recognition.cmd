@echo off
setlocal
set "ROOT=%~dp0"
"%ROOT%.venv\Scripts\python.exe" -m app m5 --mode recognition_only --profile "%ROOT%resources\web_profiles\intranet_v1.json" --templates "%ROOT%resources\image_templates\intranet_v1" --image "%~1" --annotated "%ROOT%field.annotated.png" --output "%ROOT%field.report.json"
endlocal
